import argparse
import numpy as np
import networkx as nx
import random
import math

import pandas as pd
import torch
from gensim.models import Word2Vec


def parse_args():
    parser = argparse.ArgumentParser(description="Just")

    parser.add_argument('--input', type=str, default='edges1.txt')

    parser.add_argument('--node_types', type=str, default='data/node.type')

    parser.add_argument('--output', type=str, default='result1.txt')

    parser.add_argument('--num_walks', type=int, default=40)

    parser.add_argument('--window-size', type=int, default=10)

    parser.add_argument('--alpha', type=float, default=0.025, help="学习率")

    parser.add_argument('--workers', default=1)

    parser.add_argument('--dimensions', type=int, default=128, help="训练后每个节点输出的维度")

    parser.add_argument('--walk_length', type=int, default=10, help="获取随机游走序列的长度")

    parser.add_argument('--epochs', type=int, default=5, help="epochs")

    return parser.parse_args()


args = parse_args()


# number of memorized domains = 1
def dblp_generation(G, path_length, heterg_dictionary, start=None):
    path = []

    path.append(start)

    cnt = 1
    homog_length = 1
    no_next_types = 0

    heterg_probability = 0

    while len(path) < path_length:
        if no_next_types == 1:
            break

        cur = path[-1]
        homog_type = []
        heterg_type = []
        for node_type in heterg_dictionary:
            if cur[0] == node_type:
                homog_type = node_type
                heterg_type = heterg_dictionary[node_type]

        heterg_probability = 1 - math.pow(args.alpha, homog_length)
        r = random.uniform(0, 1)
        next_type_options = []
        if r <= heterg_probability:
            for heterg_type_iterator in heterg_type:
                next_type_options.extend([e for e in G[cur] if (e[0] == heterg_type_iterator)])
            if not next_type_options:
                next_type_options = [e for e in G[cur] if (e[0] == homog_type)]
        else:
            next_type_options = [e for e in G[cur] if (e[0] == homog_type)]
            if not next_type_options:
                for heterg_type_iterator in heterg_type:
                    next_type_options.extend([e for e in G[cur] if (e[0] == heterg_type_iterator)])
        if not next_type_options:
            no_next_types = 1
            break

        next_node = random.choice(next_type_options)
        path.append(next_node)
        if next_node[0] == cur[0]:
            homog_length = homog_length + 1
        else:
            homog_length = 1

    return path


def generate_walks(G, num_walks, walk_length, heterg_dictionary):
    print('Generating walks .. ')
    walks = []
    nodes = list(G.nodes())

    for cnt in range(num_walks):
        random.shuffle(nodes)
        for node in nodes:
            just_walks = dblp_generation(G, walk_length, heterg_dictionary, start=node)
            walks.append(just_walks)
    print(str(num_walks)+ ' times walks,all Walks done .. ')
    return walks


def generate_node_types():
    heterg_dictionary = {}
    heterogeneous_node_types = open(args.node_types)

    for line in heterogeneous_node_types:
        node_type = (line.split(":")[0]).strip()
        hete_value = (line.split(":")[1]).strip()
        if node_type in heterg_dictionary.keys():
            heterg_dictionary[node_type].append(hete_value)
        else:
            heterg_dictionary[node_type] = [hete_value]

    return heterg_dictionary


def train(args):
    """处理xlsx，生成对边文件b.txt,存在的话就不要执行# process_data()了"""
    # process_data()
    G = nx.read_edgelist(args.input)
    heterg_dictionary = generate_node_types()
    walks = generate_walks(G, args.num_walks, args.walk_length, heterg_dictionary)
    print('Just Model Starting training .. ')
    model = Word2Vec(walks, vector_size=args.dimensions, window=args.window_size, min_count=5, workers=args.workers,
                     epochs=args.epochs)
    print('Just Model Finished training .. ')
    model.wv.save_word2vec_format(args.output, sort_attr='str')
    # model.wv.save_word2vec_format('result.txt', binary=False)


"""读取图生成边"""


# def process_data():
#
#     A = pd.read_csv('./data/associationMatrix_2738_275.csv', delimiter=',', header=None)  #
#     circSimi = np.loadtxt('./data/Integrated_sqe_fun_circRNA_similarity_2738.csv', delimiter=',')
#     disSimi = np.loadtxt('./data/Integrated_gip_DO_disease_similarity_275.csv', delimiter=',')
#     matAdj_circ = np.where(circSimi > 0.5, 1, 0)
#     matAdj_dis = np.where(disSimi > 0.5, 1, 0)
#
#
#     adj = A.values
#     for i, x in np.ndenumerate(adj):
#         if x == 1:
#             edge = list(i)
#             c = 'c' + str(edge[0])
#             r = 'r' + str(edge[1])
#             with open(args.input, "a", encoding='utf-8') as f:
#                 f.write(c + " " + r + "\n")
#     for i, x in np.ndenumerate(matAdj_circ):
#         if x == 1:
#             edge = list(i)
#             c = 'c' + str(edge[0])
#             r = 'c' + str(edge[1])
#             with open(args.input, "a", encoding='utf-8') as f:
#                 f.write(c + " " + r + "\n")
#     for i, x in np.ndenumerate(matAdj_dis):
#         if x == 1:
#             edge = list(i)
#             c = 'r' + str(edge[0])
#             r = 'r' + str(edge[1])
#             with open(args.input, "a", encoding='utf-8') as f:
#                 f.write(c + " " + r + "\n")
#                 f.close()
def process_data():
    default_value = 0.0
    default_value1 = 0.0
    default_value2 = 0.0

    # 使用filling_values参数从CSV文件加载数据
    A = np.genfromtxt('./data599/associationMatrix_599_88.csv', delimiter=',', filling_values=default_value)
    circSimi = np.genfromtxt('./data599/Integrated_sqe_fun_circRNA_similarity_599.csv', delimiter=',',
                             filling_values=default_value1)
    disSimi = np.genfromtxt('./data599/Integrated_gip_DO_disease_similarity_88.csv', delimiter=',',
                            filling_values=default_value2)
    matAdj_circ = np.where(circSimi > 0.5, 1, 0)
    matAdj_dis = np.where(disSimi > 0.5, 1, 0)

    # Convert A to a Pandas DataFrame
    adj_df = pd.DataFrame(A)

    with open('edges1.txt', "a", encoding='utf-8') as f:
        for i, x in np.ndenumerate(adj_df.values):
            if x == 1:
                edge = list(i)
                c = 'c' + str(edge[0])
                r = 'r' + str(edge[1])
                f.write(c + " " + r + "\n")

        for i, x in np.ndenumerate(matAdj_circ):
            if x == 1:
                edge = list(i)
                c = 'c' + str(edge[0])
                r = 'c' + str(edge[1])
                f.write(c + " " + r + "\n")

        for i, x in np.ndenumerate(matAdj_dis):
            if x == 1:
                edge = list(i)
                c = 'r' + str(edge[0])
                r = 'r' + str(edge[1])
                f.write(c + " " + r + "\n")

    """
       处理just模型输出的向量，输出的result文件中含有每个节点的向量，
       他们是718个字符串，需要转成数字，并且每个节点顺序和模型的不一样，需要重新排序
       """
# process_data()
# train(args)
def get_just_result():
    # train(args)
    datas = pd.read_csv('result1.txt', header=0)
    data = datas.values
    list = []
    for items in data:
        list.append(items[0].split(' '))
    list_c = []
    list_r = []
    for items in list:
        if items[0][0] == 'r':
            list_r.append(items)
        if items[0][0] == 'c':
            list_c.append(items)

    for items in list_c:
        for i in range(len(items)):
            if i == 0:
                items[i] = int(items[i][1:])
            if i != 0:
                items[i] = float(items[i])

    for items in list_r:
        for i in range(len(items)):
            if i == 0:
                items[i] = int(items[i][1:])
            if i != 0:
                items[i] = float(items[i])

    list_r.sort(key=lambda x: x[0], reverse=False)
    list_c.sort(key=lambda x: x[0], reverse=False)

    just_c = torch.Tensor(np.array(list_c)[:, 1:])
    just_r = torch.Tensor(np.array(list_r)[:, 1:])

    return torch.cat((just_c, just_r), dim=0)